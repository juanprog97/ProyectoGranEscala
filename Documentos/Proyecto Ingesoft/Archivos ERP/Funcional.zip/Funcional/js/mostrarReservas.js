$(buscar_reservas());

function buscar_reservas(consulta)
{
	$.ajax({
		url: 'php/mostrarReservas.php',
		type: 'POST',
		datatype: 'html',
		data: {consulta: consulta},
	})

	.done(function(respuesta){
		$("#tabla_resultado").html(respuesta);
	})
}

$(document).on('change', '#fdreserva', function()
{
	var valor = $(this).val();
	if(valor != "")
	{
		buscar_reservas(valor);
	} 
	else 
	{
		buscar_reservas("2018-06-05");
	}
});