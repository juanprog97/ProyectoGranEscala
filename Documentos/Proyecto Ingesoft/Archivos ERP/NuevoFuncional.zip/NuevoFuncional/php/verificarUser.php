<?php
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
	$dbServer="localhost";
	$dbUser="root";
	$dbPass="admin123"; //Enter MySQL password here.
	$dbName="sistema_erp";
	$mysqli = new mysqli("$dbServer", "$dbUser", "$dbPass","$dbName");
	$salida = "";
	$query = "SELECT * FROM tb_usuario ORDER BY Nombre";

	if(isset($_POST['consulta'])){
		$q = $mysqli->real_escape_string($_POST['consulta']);
		$query = "SELECT NombreUsuario FROM tb_usuario WHERE  NombreUsuario= '$q'";
		echo mysqli_error($mysqli);
	}

	$resultado = $mysqli->query($query);

	if($resultado->num_rows > 0){
		$salida.="<p>El usuario ya se encuentra en uso.</p>";

	} else {
		$salida.="<p>El usuario está disponible</p>";
	}

	echo $salida;

	$mysqli->close();
?>