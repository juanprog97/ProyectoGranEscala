<?php
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
	$dbServer="localhost";
	$dbUser="root";
	$dbPass="admin123"; //Enter MySQL password here.
	$dbName="reservas";
	$mysqli = new mysqli("$dbServer", "$dbUser", "$dbPass","$dbName");
	$salida = "";
	$query = "SELECT * FROM demo ORDER BY fname";

	if(isset($_POST['consulta'])){
		$q = $mysqli->real_escape_string($_POST['consulta']);
		$query = "SELECT fname, ftime FROM demo WHERE fdreserva = '$q'";
	}

	$resultado = $mysqli->query($query);

	if($resultado->num_rows > 0){
		$salida.="<table class='tabla_reservas'>
						<thead>
							<tr>
								<td>Zona Comun</td>
								<td>Hora Inicio</td>
							</tr>
						</thead>
						<tbody>";
		while($fila = $resultado->fetch_assoc()){
			$salida.="<tr>
						<td>".$fila['fname']."</td>
						<td>".$fila['ftime']."</td>
					</tr>";
		}

		$salida.="</tbody></table>";

	} else {
		$salida.="No hay reservas";
	}

	echo $salida;

	$mysqli->close();
?>