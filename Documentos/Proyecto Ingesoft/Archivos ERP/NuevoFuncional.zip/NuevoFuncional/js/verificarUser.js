$(buscar_user());

function buscar_user(consulta)
{
	$.ajax({
		url: 'php/verificarUser.php',
		type: 'POST',
		datatype: 'html',
		data: {consulta: consulta},
	})

	.done(function(respuesta){
		$("#checked").html(respuesta);
	})
}

$(document).on('change', '#userBox', function()
{
	var valor = $(this).val();
	if(valor != "")
	{
		buscar_user(valor);
	} 
	else 
	{
		buscar_user("root");
	}
});